# Weblate localization

This fork currently keeps the same Android string resources as upstream Fold Craft Launcher, rebranded to OrbitX.

If you stand up Weblate for OrbitX:

- Name: `OrbitX Launcher`
- Slug: `orbitx-launcher`
- File mask: `FCL/src/main/res/values-*/strings.xml`
- Monolingual base: `FCL/src/main/res/values/strings.xml`
- File format: Android String Resource

Upstream FCL translations: https://hosted.weblate.org/projects/foldcraftlauncher/
