<div align="center">
    <img width="96" src="/FCL/src/main/res/drawable/img_app.png" alt="OrbitX Launcher" />
</div>

<h1 align="center">OrbitX Launcher</h1>

<div align="center">

[![Android CI](https://github.com/VenZ9/OrbitX-Launcher/actions/workflows/build.yml/badge.svg)](https://github.com/VenZ9/OrbitX-Launcher/actions/workflows/build.yml)
![Release](https://img.shields.io/github/v/release/VenZ9/OrbitX-Launcher?style=flat-square&color=c0392b)

</div>

🌍 **Язык**  
[简体中文](./README.md) | [English](./README_EN.md) | Русский язык

> **OrbitX Launcher** — лаунчер Minecraft: Java Edition для Android. Это ребрендинг-форк [Fold Craft Launcher](https://github.com/FCL-Team/FoldCraftLauncher) (FCL-Team) на базе [HMCL](https://github.com/HMCL-dev/HMCL) и бэкенда [Amethyst-Android](https://github.com/AngelAuraMC/Amethyst-Android).

---

## Возможности

- Все версии Minecraft, включая снапшоты
- Forge / NeoForge / LiteLoader / OptiFine / Fabric / Quilt / Cleanroom
- Java 8 / 17 / 21 / 25 и импорт своей Java
- Виртуальная мышь и раскладки управления
- Шейдеры (VirGL / Zink / MG)
- Моды, сборки, ресурспаки, миры
- Тема: тёмный фон и багровый акцент `#C0392B`

| | Fold Craft Launcher | OrbitX Launcher |
|---|---|---|
| Имя | Fold Craft Launcher | **OrbitX Launcher** |
| applicationId | `com.tungsten.fcl` | **`com.orbitx.launcher`** |
| Каталог | `/FCL/.minecraft` | `/OrbitX/.minecraft` |

---

## Лицензия

GPL-3.0. Апстрим: [FCL-Team/FoldCraftLauncher](https://github.com/FCL-Team/FoldCraftLauncher)
