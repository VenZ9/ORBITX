<div align="center">
    <img width="96" src="/FCL/src/main/res/drawable/img_app.png" alt="OrbitX Launcher" />
</div>

<h1 align="center">OrbitX Launcher</h1>

<div align="center">

[![Android CI](https://github.com/VenZ9/OrbitX-Launcher/actions/workflows/build.yml/badge.svg)](https://github.com/VenZ9/OrbitX-Launcher/actions/workflows/build.yml)
![Release](https://img.shields.io/github/v/release/VenZ9/OrbitX-Launcher?style=flat-square&color=c0392b)

</div>

🌍 **语言**  
简体中文 | [English](./README_EN.md) | [Русский язык](./README_RU.md)

> **OrbitX Launcher** 是 Android 平台的 Minecraft: Java Edition 启动器。本仓库是 [Fold Craft Launcher](https://github.com/FCL-Team/FoldCraftLauncher)（FCL-Team）的重制分支，核心来自 [HMCL](https://github.com/HMCL-dev/HMCL)，后端使用 [Amethyst-Android](https://github.com/AngelAuraMC/Amethyst-Android)。

---

## 核心特性

**全版本支持**
- 原生支持 Minecraft 全版本（包括最新快照）
- 模组加载器：Forge / NeoForge / LiteLoader / OptiFine / Fabric / Quilt / Cleanroom

**功能亮点**
- 内置 Java 8 / 17 / 21 / 25，支持导入自定义 Java
- 虚拟鼠标与自定义按键映射
- 与 ZalithLauncher2 控制布局互转
- 光影（VirGL / Zink / MG）
- 模组 / 整合包 / 材质 / 光影 / 存档
- 默认主题：暗色底 + 轨道绯红 `#C0392B`（设置中仍可自定义）
- 渲染器插件

---

## 品牌对照

| | Fold Craft Launcher | OrbitX Launcher |
|---|---|---|
| 应用名 | Fold Craft Launcher | **OrbitX Launcher** |
| 包名 | `com.tungsten.fcl` | **`com.orbitx.launcher`** |
| 主题色 | 蓝 `#7797CF` | 绯红 `#C0392B` |
| 游戏目录 | `/FCL/.minecraft` | `/OrbitX/.minecraft` |
| 图标 | FCL | 绯红轨道环 |

Java 包名（`com.tungsten.fcl…`）保持不变，便于同步上游。

---

## 许可

GPL-3.0，与 Fold Craft Launcher 相同。本分支必须保持开源。

上游：[FCL-Team/FoldCraftLauncher](https://github.com/FCL-Team/FoldCraftLauncher)
