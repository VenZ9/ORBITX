<div align="center">
    <img width="96" src="/FCL/src/main/res/drawable/img_app.png" alt="OrbitX Launcher" />
</div>

<h1 align="center">OrbitX Launcher</h1>

<div align="center">

[![Android CI](https://github.com/VenZ9/OrbitX-Launcher/actions/workflows/build.yml/badge.svg)](https://github.com/VenZ9/OrbitX-Launcher/actions/workflows/build.yml)
![Release](https://img.shields.io/github/v/release/VenZ9/OrbitX-Launcher?style=flat-square&color=c0392b)

</div>

🌍 **Language**  
[简体中文](./README.md) | English | [Русский язык](./README_RU.md)

> **OrbitX Launcher** is a Minecraft: Java Edition launcher for Android. It is a rebranded fork of [Fold Craft Launcher](https://github.com/FCL-Team/FoldCraftLauncher) (FCL-Team), built on [HMCL](https://github.com/HMCL-dev/HMCL) with the [Amethyst-Android](https://github.com/AngelAuraMC/Amethyst-Android) backend.

---

## Core features

**Full version support**
- Native support for all Minecraft versions (including latest snapshots)
- Mod loaders: Forge / NeoForge / LiteLoader / OptiFine / Fabric / Quilt / Cleanroom

**Highlights**
- Built-in Java runtimes (8 / 17 / 21 / 25) plus custom Java import
- Virtual mouse and customizable key mapping
- Control-layout conversion with ZalithLauncher2
- Shader support (VirGL / Zink / MG renderers)
- Mods, modpacks, resource packs, shaders, and worlds
- Theme color: Orbit crimson on a dark field (still customizable in settings)
- Renderer plugins

---

## Branding

| | Fold Craft Launcher | OrbitX Launcher |
|---|---|---|
| App name | Fold Craft Launcher | **OrbitX Launcher** |
| Application ID | `com.tungsten.fcl` | **`com.orbitx.launcher`** |
| Theme | Blue `#7797CF` | Crimson `#C0392B` |
| Game dir | `/FCL/.minecraft` | `/OrbitX/.minecraft` |
| Icon | FCL mark | Crimson orbit ring |

Java package names (`com.tungsten.fcl…`) are unchanged so the codebase stays mergeable with upstream.

---

## License

GPL-3.0 — same as Fold Craft Launcher. This fork must remain open source.

Upstream: [FCL-Team/FoldCraftLauncher](https://github.com/FCL-Team/FoldCraftLauncher)

---

## Related projects

- [HMCL](https://github.com/HMCL-dev/HMCL)
- [Amethyst-Android](https://github.com/AngelAuraMC/Amethyst-Android)
- [authlib-injector](https://github.com/yushijinhun/authlib-injector)
- [Terracotta](https://github.com/burningtnt/Terracotta)
- [TouchController](https://github.com/TouchController/TouchController)
- [NG-GL4ES](https://github.com/ShirosakiMio/NG-GL4ES)
